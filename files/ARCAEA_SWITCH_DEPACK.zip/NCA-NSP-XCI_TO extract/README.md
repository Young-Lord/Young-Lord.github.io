# 4NXCI

![License](https://img.shields.io/badge/license-ISC-blue.svg)

4NXCI is a tool for converting XCI(NX Card Image) files to NSP  
It's in early stages and there are lots to be done  
You need to place your keyset file with "keys.dat" filename in the same folder as program  

4NXCI is based on hactool by SciresM [hactool](https://github.com/SciresM/hactool)

## Licensing

This software is licensed under the terms of the ISC License.  
You can find a copy of the license in the LICENSE file.
