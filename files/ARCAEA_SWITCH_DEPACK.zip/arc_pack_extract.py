#Arcaea wiki @LYNiko
#Github@Young-Lord
#VERSION 2
DISABLE_VERBOSE = False  # 设为True以关闭具体文件列表输出
VERBOSE_SPACING = 400  # 每隔多少个VERBOSE提示,设为0以开启所有VERBOSE

import json
import os

json_ok = False


def getFile(hint_str=""):
    print(hint_str, end="")
    raw_str = input()
    if raw_str.find('&') == 0:
        raw_str = raw_str[2:]  # f**k powershell
    raw_str = raw_str.replace('"', '').replace("'", "")
    return raw_str


while True:
    cur_files=os.listdir()
    if "arc.json" in cur_files and "arc.pack" in cur_files:
        json_file = "arc.json"
        pack_file = "arc.pack"
        break
    elif "arc_1.json" in cur_files and "arc_1.pack" in cur_files:
        json_file = "arc_1.json"
        pack_file = "arc_1.pack"
    if not json_ok:
        json_file = getFile("[ASK] 请拖入JSON文件：")
        if not os.path.isfile(json_file):
            print("[ERROR] 文件错误，请重试。")
            continue
        json_ok = True
    filepath = os.path.dirname(os.path.abspath(json_file))
    if os.path.isfile(os.path.splitext(os.path.abspath(json_file))[0]+".pack"):
        print("[INFO] 已自动匹配"+os.path.splitext(json_file)[0]+".pack")
        pack_file = os.path.splitext(json_file)[0]+".pack"
        break
    else:
        pack_file = getFile("[ASK] 请拖入PACK文件：")
        if not os.path.isfile(pack_file):
            print("[ERROR] 文件错误，请重试。")
            continue
        else:
            break
# 淦，一个文件匹配都写得这么麻烦
with open(json_file, encoding="utf-8") as jf:
    try:
        json_content = [i["OrderedEntries"] for i in json.load(jf)["Groups"]]
    except:
        print("[ERROR] 读取文件出错！")
        os.system("pause")
json_content = sum(json_content, [])  # 展平
os.makedirs("finally_result", exist_ok=True)
print()
print("="*20)
print("[INFO] 开始进行提取")
print("="*20)
print()
VERBOSE_COUNTER = 0
with open(pack_file, "rb") as pf:
    for i in json_content:
        cur_file_name = os.path.join("finally_result", i["OriginalFilename"])
        os.makedirs(os.path.dirname(cur_file_name), exist_ok=True)
        if os.path.isfile(cur_file_name):
            print("[WARNING] 文件{}已存在，跳过".format(cur_file_name))
            continue
        with open(cur_file_name, "wb") as target:
            pf.seek(i["Offset"])
            target.write(pf.read(i["Length"]))
        VERBOSE_COUNTER += 1
        if DISABLE_VERBOSE or (VERBOSE_SPACING!=0 and VERBOSE_COUNTER % (VERBOSE_SPACING+1) != 1):
            continue
        print("[VERBOSE] 已提取{}".format(i["OriginalFilename"]))

print("[INFO] 提取完成！")
print("[INFO] 共提取了 {} 个文件。".format(VERBOSE_COUNTER))
ret_val = os.system("explorer .\\finally_result")
print("""
********************
WELCOME TO ARCAEA!
********************
""")
